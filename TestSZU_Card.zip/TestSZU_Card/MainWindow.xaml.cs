﻿

using System.Windows;
using TestSZU_Card.SZU_Pay;
using TestSZU_Card.SZU_Pay.Structs;

namespace TestSZU_Card
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// 流水号
        /// </summary>
        private uint uJnl = 0;

        public MainWindow()
        {
            InitializeComponent();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //bool bOffline = true;
            //ulong uJnl = 0;
            ////全局初始化类的API函数
            ////bool b = Utils.CardManager.My_TA_Init("127.0.0.1", 8500, 20, 1, ref bOffline, ref uJnl);
            ////bool b = Utils.CardManager.My_TA_Init("210.39.3.185", 8500, 167, 71, ref bOffline, ref uJnl);
            //bool b = Utils.CardManager.My_TA_Init("210.39.14.91", 8500, 167, 71, ref bOffline, ref uJnl);
            //Console.WriteLine("bOffline={0},uJnl={1},b={2}", bOffline, uJnl, b);

            ////初始化读卡器
            //char CardReaderType = '1';
            //Console.WriteLine(Utils.CardManager.My_TA_CRInit(CardReaderType, 0, 9600));

            //IntPtr handle = Utils.CardManager.My_ReadCard_Init(1, 12800);
            //Console.WriteLine("初始化读卡器："+ handle);
            //Console.WriteLine("读卡器蜂鸣(返回-1表示失败,0表示成功)：" + Utils.CardManager.My_Card_Beep(handle, 10000));




            //Mondel.AccountMsg am = new Mondel.AccountMsg();
            //am.AccountNo = 5;
            ////获取持卡人账户信息
            //int nRet = Utils.CardManager.My_TA_InqAcc(ref am);
            //Console.WriteLine("nRet={0} ,am={1}",nRet, Newtonsoft.Json.JsonConvert.SerializeObject(am));

            ////读卡器峰鸣
            //int beep=Utils.CardManager.My_TA_CRBeep(10000);
            //Console.WriteLine("beep={0}",beep);



        }

        /// <summary>
        /// 初始化动态库AIO_API.dll
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnInitAIO_API_dll_Click(object sender, RoutedEventArgs e)
        {
            //初始化第三方动态库
            //string IP = "210.39.3.185 ";// 第三方代理服务器SIOS的IP地址
            string IP = txtIP.Text.Trim();
            if (!Common.CheckFormat.IsIP(IP))
            {
                rtbShow.AppendText("IP地址错误,请检查后再试！\r\n");
                rtbShow.ScrollToEnd();
                return;
            }

            //short port =8500; //第三方代理服务器sios 的端口号
            short port; //第三方代理服务器sios 的端口号
            if (!short.TryParse(txtPort.Text.Trim(), out port) || port < 0 || port > short.MaxValue)
            {
                rtbShow.AppendText("端口号有误,请检查后再试！（0~" + short.MaxValue + ")\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            //ushort SysCode = 167; //给第三方系统分配的系统代码
            //ushort TerminalNo = 71; //终端编号
            //ushort SysCode = 15; //给第三方系统分配的系统代码
            //ushort TerminalNo = 1; //终端编号

            ushort SysCode; //给第三方系统分配的系统代码
            if (!ushort.TryParse(txtSysCode.Text.Trim(),out SysCode))
            {
                rtbShow.AppendText("系统代码有误,请检查后再试！（0~" + short.MaxValue + ")\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            ushort TerminalNo; //终端编号
            if (!ushort.TryParse(txtTerminalNo.Text.Trim(), out TerminalNo))
            {
                rtbShow.AppendText("终端编号有误,请检查后再试！（0~" + short.MaxValue + ")\r\n");
                rtbShow.ScrollToEnd();
                return;
            }

            bool ProxyOffline; //代理服务是否脱机
            //ulong MaxJnl; //最大流水号
            uint MaxJnl; //最大流水号
            bool isInit = TaManager.TA_Init(IP, port, SysCode, TerminalNo, out ProxyOffline, out MaxJnl);
            if (isInit)//初始化成功
            {
                rtbShow.AppendText("初始化动态库成功！ 代理服务是否脱机：" + ProxyOffline + "  最大流水号:" + MaxJnl + "  \r\n");
                btnInitAIO_API_dll.Content = "初始化动态库(已初始化)";
                uJnl = MaxJnl;//流水号
            }
            else
            {
                rtbShow.AppendText("初始化动态库失败！\r\n");
                btnInitAIO_API_dll.Content = "初始化动态库(未初始化)";
            }
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();
        }


        //获取持卡人账户信息
        private void btnInqAcc_Click(object sender, RoutedEventArgs e)
        {
            AccountMsg accountMsg = new AccountMsg();
            string accountNoStr = txtAccountNo.Text.Trim();
            string cardNoStr = txtCardNo.Text.Trim();
            string studentCodeStr = txtStudentCode.Text.Trim();
            string idCardStr = txtIDCard.Text.Trim();
            //if (!string.IsNullOrEmpty(accountNoStr))
            //{
            //    if (Common.CheckFormat.IsInt(accountNoStr))
            //    {
            //        uint.TryParse(accountNoStr,out accountMsg.AccountNo);
            //    }

            //}
            //if (!cardNoStr.Equals(""))
            //{
            //    if (!Common.CheckFormat.IsInt(cardNoStr))
            //    {
            //        rtbShow.AppendText("CardNo输入有误，请查正后再试！\r\n");
            //        rtbShow.ScrollToEnd();
            //        return;
            //    }
            //}
            if (!string.IsNullOrEmpty(accountNoStr))
            {
                uint.TryParse(accountNoStr, out accountMsg.AccountNo);// AccountNo – 消费卡片的帐号
            }
            if (!string.IsNullOrEmpty(cardNoStr))
            {
                uint.TryParse(cardNoStr, out accountMsg.CardNo);// CardNo – 消费卡的卡号
                //uint cardNo;
                //uint.TryParse(cardNoStr, out cardNo);// CardNo – 消费卡的卡号
                //if (cardNo>0)
                //{
                //    accountMsg.CardNo = BitConverter.GetBytes(cardNo);
                //}
            }
            if (!string.IsNullOrEmpty(studentCodeStr))
            {
                accountMsg.StudentCode = studentCodeStr;
            }
            if (!string.IsNullOrEmpty(idCardStr))
            {
                accountMsg.IDCard = idCardStr;
            }


            //accountMsg.CardNo = uint.Parse(cardNoStr);//1853160300     990015092
            //accountMsg.AccountNo = 808452096;
            //accountMsg.IDCard = "ENTITY556677889900";

            //rtbShow.AppendText(Newtonsoft.Json.JsonConvert.SerializeObject(accountMsg) + "\r\n");

            //accountMsg.AccType = "001";

            int isTA_InqAcc = TaManager.TA_InqAcc(ref accountMsg, 10);
            rtbShow.AppendText("获取持卡人账户信息状态：" + isTA_InqAcc + Errormsg.GetEnumFroByKey(isTA_InqAcc) + "\r\n");
            //rtbShow.AppendText(Newtonsoft.Json.JsonConvert.SerializeObject(accountMsg) + "\r\n");
            rtbShow.AppendText(StructUtils.AccountMsgToString(accountMsg));
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();
        }

        //获取持卡人账户信息及其扩展信息
        private void btnTA_InqAccEx_Click(object sender, RoutedEventArgs e)
        {
            AccountMsg accountMsg = new AccountMsg();
            string accountNoStr = txtAccountNo.Text.Trim();
            string cardNoStr = txtCardNo.Text.Trim();
            string studentCodeStr = txtStudentCode.Text.Trim();
            string idCardStr = txtIDCard.Text.Trim();

            if (!string.IsNullOrEmpty(accountNoStr))
            {
                uint.TryParse(accountNoStr, out accountMsg.AccountNo);// AccountNo – 消费卡片的帐号
            }
            if (!string.IsNullOrEmpty(cardNoStr))
            {
                uint.TryParse(cardNoStr, out accountMsg.CardNo);// CardNo – 消费卡的卡号
                //uint cardNo;
                //uint.TryParse(cardNoStr, out cardNo);// CardNo – 消费卡的卡号
                //if (cardNo > 0)
                //{
                //    accountMsg.CardNo = BitConverter.GetBytes(cardNo);
                //}
            }
            if (!string.IsNullOrEmpty(studentCodeStr))
            {
                accountMsg.StudentCode = studentCodeStr;
            }
            if (!string.IsNullOrEmpty(idCardStr))
            {
                accountMsg.IDCard = idCardStr;
            }

            int isTA_InqAccEx = TaManager.TA_InqAccEx(ref accountMsg, 10);
            rtbShow.AppendText("获取持卡人账户信息及其扩展信息状态：" + isTA_InqAccEx + Errormsg.GetEnumFroByKey(isTA_InqAccEx) + "\r\n");
            rtbShow.AppendText(StructUtils.AccountMsgToString(accountMsg));
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();


            ////调试
            //AccountMsg_Debug accountMsg_Debug = new AccountMsg_Debug();
            //accountMsg_Debug.debugByteArry = new byte[255];//42 ->6CFB746E
            //accountMsg_Debug.debugByteArry[42] = 0x6C;
            //accountMsg_Debug.debugByteArry[43] = 0xFB;
            //accountMsg_Debug.debugByteArry[44] = 0x74;
            //accountMsg_Debug.debugByteArry[45] = 0x6E;
            //result = TaManager.TA_InqAccEx_Debug(ref accountMsg_Debug, 10);
            //rtbShow.AppendText("获取持卡人账户信息及其扩展信息：" + result + "\r\n");
            //rtbShow.AppendText(Utils.ByteUtils.BytesToHexStr(accountMsg_Debug.debugByteArry));
            //rtbShow.AppendText("\r\n");
            //rtbShow.ScrollToEnd();
        }


        /// <summary>
        /// 根据帐号和卡号检查白名单。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTA_CheckWL_Click(object sender, RoutedEventArgs e)
        {
            uint cardNo, accountNo;
            uint.TryParse(txtCardNo.Text.Trim(),out cardNo);
            uint.TryParse(txtAccountNo.Text.Trim(),out accountNo);
            if (cardNo<1 || accountNo<1)
            {
                rtbShow.AppendText("账号AccountNo或者卡号CardNo输入有误，请查正后再试！\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            int isTA_CheckWL=TaManager.TA_CheckWL(accountNo,cardNo,true);
            rtbShow.AppendText("根据帐号和卡号检查白名单状态：" + isTA_CheckWL + Errormsg.GetEnumFroByKey(isTA_CheckWL)+ "\r\n");
            rtbShow.ScrollToEnd();
        }

        /// <summary>
        /// 根据帐号(AccountNo)/卡号(CardNo)E账户消费(默认使用账号AccountNo，备用使用卡号CardNo)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTA_Elec_Consume_Click(object sender, RoutedEventArgs e)
        {
            uint cardNo, accountNo;
            uint.TryParse(txtCardNo.Text.Trim(), out cardNo);
            uint.TryParse(txtAccountNo.Text.Trim(), out accountNo);
            if (accountNo < 1 && cardNo < 1)
            {
                rtbShow.AppendText("账号AccountNo/卡号CardNo输入有误，请查正后再试！(默认使用账号AccountNo，备用使用卡号CardNo)\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            CardConsume_E cardConsume_E = new CardConsume_E();
            cardConsume_E.AccountNo = accountNo;//账号
            if (cardConsume_E.AccountNo<1)
            {
                cardConsume_E.CardNo = cardNo;//卡号
            }
            //cardConsume_E.TerminalNo = 1;//终端编号
            //cardConsume_E.TerminalNo = 71;//终端编号
            if (!ushort.TryParse(txtTerminalNo.Text.Trim(), out cardConsume_E.TerminalNo))
            {
                rtbShow.AppendText("终端编号有误,请检查后再试！（0~" + short.MaxValue + ")\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            //cardConsume_E.Operator = "01";//操作员
            //cardConsume_E.Operator = "cg";//操作员
            cardConsume_E.Operator = txtOperator.Text.Trim();
            if (cardConsume_E.Operator.Length!=2)//操作员代码的操作员代码，填写两个字节的操作员代码
            {
                rtbShow.AppendText("操作员代码有误,请检查后再试！（操作员代码的操作员代码，填写两个字节的操作员代码)\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            int tranAmt;
            int.TryParse(txtTranAmt_E.Text.Trim(), out tranAmt);
            if (tranAmt <= 0)//卡片消费的交易额，必须小于0
            {
                rtbShow.AppendText("消费金额TranAmt输入有误，请查正后再试！(消费金额必须大于0的整数)\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            cardConsume_E.TranAmt = -tranAmt;//交易额，精确到分
            cardConsume_E.TranJnl = uJnl++;//交易流水号
            //cardConsume_E.AccType = "001";//转出账户类型001
            cardConsume_E.AccType = "002";//转出账户类型001


            int isTA_Elec_Consume = TaManager.TA_Elec_Consume(ref cardConsume_E, 10);
            rtbShow.AppendText("根据帐号(AccountNo)E账户消费状态：" + isTA_Elec_Consume + Errormsg.GetEnumFroByKey(isTA_Elec_Consume) + "\r\n");
            rtbShow.AppendText(StructUtils.CardConsume_E_ToString(cardConsume_E) + "\r\n");
            rtbShow.ScrollToEnd();
        }


        //初始化读卡器
        private void btnTA_CRInit_Click(object sender, RoutedEventArgs e)
        {
            int isTa_CrInit=-1;
            byte cardReaderType;//读卡器类型（usb=0；串口=1）
            if ((bool)rbtUSB.IsChecked)//选择了USB读卡器
            {
                cardReaderType = 0;
                isTa_CrInit = TaManager.TA_CRInit(cardReaderType, 1, 19200);
            }
            else//选择了串口读卡器
            {
                cardReaderType = 1;
                //if (cbSerialPortName.SelectedIndex<1)//串口号没有选
                //{
                //    MessageBox.Show("请先选择串口读卡器对应的串口号!");
                //    return;
                //}
                //if (cbBaudRale.SelectedIndex<1)//波特率没有选
                //{
                //    MessageBox.Show("请先选择串口读卡器对应的波特率！");
                //    return;
                //}
                string serialPortName = cbSerialPortName.Text;
                int port;
                int.TryParse(serialPortName.Replace("com", "").Replace("COM", "").Trim(),out port);
                if (port<1)
                {
                    MessageBox.Show("请先选择串口读卡器对应的串口号!");
                    return;
                }
                int baudRale;
                int.TryParse(cbBaudRale.Text.Trim(),out baudRale);
                if (baudRale<1)
                {
                    MessageBox.Show("请先选择/输入串口读卡器对应的波特率！");
                    return;
                }
                isTa_CrInit = TaManager.TA_CRInit(cardReaderType, port, baudRale);
            }


            
            rtbShow.AppendText("初始化读卡器状态：" + isTa_CrInit + Errormsg.GetEnumFroByKey(isTa_CrInit) + "\r\n");
            if (isTa_CrInit == 0)
            {
                if (cardReaderType==0)//usb
                {
                    btnTA_CRInit.Content = "初始化读卡器(已初始化USB)";
                }
                else if (cardReaderType==1)//usb
                {
                    btnTA_CRInit.Content = "初始化读卡器(已初始化串口)";
                }
                else
                {
                    btnTA_CRInit.Content = "初始化读卡器(已初始化)";
                }
                
            }
            else
            {
                btnTA_CRInit.Content = "初始化读卡器(未初始化)";
            }
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();
        }

        /// <summary>
        /// 读卡-快速读卡号
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReadCard_Click(object sender, RoutedEventArgs e)
        {
            uint cardNo;
            int isTA_FastReadCard = TaManager.TA_FastGetCardNo(out cardNo);
            rtbShow.AppendText("快速读卡号状态：" + isTA_FastReadCard + Errormsg.GetEnumFroByKey(isTA_FastReadCard) + "\r\n");
            rtbShow.AppendText("卡号：" + cardNo + "\r\n");
            //AccountMsg accountMsg = new AccountMsg();
            ////int isTA_FastReadCard = TaManager.TA_FastGetCardNo(out accountMsg.CardNo);
            ////rtbShow.AppendText("快速读卡号状态：" + isTA_FastReadCard + "\r\n");
            //rtbShow.AppendText("卡号：" + accountMsg.CardNo + "\r\n");

            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();

        }

        //简单读卡信息，不检验白名单。
        private void btnTA_ReadCardSimple_Click(object sender, RoutedEventArgs e)
        {
            AccountMsg accountMsg = new AccountMsg();
            int isTA_ReadCardSimple = TaManager.TA_ReadCardSimple(ref accountMsg);
            rtbShow.AppendText("简单读卡状态：" + isTA_ReadCardSimple + Errormsg.GetEnumFroByKey(isTA_ReadCardSimple) + "\r\n");
            rtbShow.AppendText(StructUtils.AccountMsgToString(accountMsg));
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();
        }

        //读卡信息。读出卡信息并检验白名单，判断卡片的有效性。
        private void btnTA_ReadCard_Click(object sender, RoutedEventArgs e)
        {
            //AccountMsg accountMsg = new AccountMsg();
            //int isTA_ReadCard = TaManager.TA_ReadCard(ref accountMsg, true, false);
            //rtbShow.AppendText("读卡状态：" + isTA_ReadCard + "\r\n");
            //rtbShow.AppendText(AccountMsgToString(accountMsg));
            AccountMsg accountMsg = new AccountMsg();
            int isTA_ReadCard = TaManager.TA_ReadCard(ref accountMsg, true, false);
            rtbShow.AppendText("读卡状态：" + isTA_ReadCard + Errormsg.GetEnumFroByKey(isTA_ReadCard) + "\r\n");
            rtbShow.AppendText(StructUtils.AccountMsgToString(accountMsg));
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();



        }


        /// <summary>
        /// 刷卡消费卡账户
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTA_Consume_Click(object sender, RoutedEventArgs e)
        {
            //消费前读卡并校验白名单
            AccountMsg accountMsg = new AccountMsg();
            int isTA_ReadCard = TaManager.TA_ReadCard(ref accountMsg, true, false);
            rtbShow.AppendText("消费前读卡并校验白名单状态：" + isTA_ReadCard + Errormsg.GetEnumFroByKey(isTA_ReadCard) + "\r\n");
            rtbShow.AppendText("消费前读卡信息：\r\n" + StructUtils.AccountMsgToString(accountMsg));
            rtbShow.ScrollToEnd();
            if (isTA_ReadCard!=0)//读卡失败
            {
                return;
            }
            CardConsume cardConsume = new CardConsume();
            //cardConsume.TerminalNo = 1;//终端编号
            //cardConsume.TerminalNo = 71;//终端编号
            //if (!short.TryParse(txtTerminalNo.Text.Trim(), out cardConsume.TerminalNo))
            //{
            //    rtbShow.AppendText("终端编号有误,请检查后再试！（0~" + short.MaxValue + ")\r\n");
            //    rtbShow.ScrollToEnd();
            //    return;
            //}
            cardConsume.TerminalNo = ushort.Parse(accountMsg.TerminalNo.ToString());
            //cardConsume_E.Operator = "01";//操作员
            //cardConsume_E.Operator = "cg";//操作员
            cardConsume.Operator = txtOperator.Text.Trim();
            if (cardConsume.Operator.Length != 2)//操作员代码的操作员代码，填写两个字节的操作员代码
            {
                rtbShow.AppendText("操作员代码有误,请检查后再试！（操作员代码的操作员代码，填写两个字节的操作员代码)\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            int tranAmt;
            int.TryParse(txtTranAmt.Text.Trim(), out tranAmt);
            if (tranAmt <= 0)//消费金额需要小于0，故这里小于等于0不行
            {
                rtbShow.AppendText("消费金额TranAmt输入有误，请查正后再试！\r\n");
                rtbShow.ScrollToEnd();
                return;
            }
            cardConsume.TranAmt=-tranAmt;//消费金额，精确到分
            //int isTA_FastReadCard = TaManager.TA_FastGetCardNo(out cardConsume.CardNo);//快速读取卡号
            //if (isTA_FastReadCard!=0)
            //{
            //    cardConsume.CardNo = 1853160300;
            //}
            cardConsume.CardNo = accountMsg.CardNo;
            cardConsume.AccountNo = accountMsg.AccountNo;
            

            cardConsume.TranJnl = uJnl++;//交易流水号


            int isTA_Consume = TaManager.TA_Consume(ref cardConsume, true, 10);//卡消费
            rtbShow.AppendText("~~~~~~~~刷卡消费状态~~~~~~~~：" + isTA_Consume + Errormsg.GetEnumFroByKey(isTA_Consume) + "\r\n");
            rtbShow.AppendText(StructUtils.CardConsumeToString(cardConsume));
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();

        }


        //清空提示
        private void btnClearShow_Click(object sender, RoutedEventArgs e)
        {
            rtbShow.Document.Blocks.Clear();
            rtbShow.AppendText("\r\n");
        }



        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //string sql = "select * from PersonInformation";
            string sql = "select AccountNo from PersonInformation where StudentNo='1527'";//StudentNo='%s'   CardNo=
            int nBlockNum, RetCode;
            int isTA_Dsql_QFile = TaManager.TA_Dsql_QFile(sql, ';', "sql查询到的文件", out nBlockNum, out RetCode, 10);
            rtbShow.AppendText("sql查询状态：" + isTA_Dsql_QFile + "\r\n");
            rtbShow.AppendText("nblocknum返回的记录数目：" + nBlockNum + "\r\n");
            rtbShow.AppendText("Dsql查询的返回值：" + RetCode + "\r\n");
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();


        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string sql = "select AccountNo from PersonInformation where StudentNo='1527'";//StudentNo='%s'   CardNo=
            //string sBlock;
            string sBlock;
            int nBlockNum, RetCode;
            int isTA_Dsql_QFile = TaManager.TA_Dsql_QRecord(sql, ';', out sBlock, out nBlockNum, out RetCode, 10);
            rtbShow.AppendText("sql查询状态：" + isTA_Dsql_QFile + "\r\n");
            rtbShow.AppendText("sBlock返回的记录：" + sBlock + "\r\n");
            rtbShow.AppendText("nBlockNum返回的记录数：" + nBlockNum + "\r\n");
            rtbShow.AppendText("Dsql查询的返回值：" + RetCode + "\r\n");
            rtbShow.AppendText("\r\n");
            rtbShow.ScrollToEnd();
        }

        /// <summary>
        /// 窗体加载完成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //初始化串口选择下拉列表
            cbSerialPortName.Items.Clear();
            cbSerialPortName.Items.Add("-请选择串口号-");
            cbSerialPortName.SelectedIndex = 0;
            //打印所有可用串口号 
            foreach (string serialPortName in System.IO.Ports.SerialPort.GetPortNames())
            {
                cbSerialPortName.Items.Add(serialPortName);
            }
            if (cbSerialPortName.Items.Count>1)
            {
                cbSerialPortName.SelectedIndex = 1;//有串口号的情况下默认选中第一个
            }
            

            //初始化波特率选择下拉列表
            cbBaudRale.Items.Clear();
            cbBaudRale.Items.Add("-请选择波特率-");
            cbBaudRale.SelectedIndex = 0;
            cbBaudRale.Items.Add("300");
            cbBaudRale.Items.Add("600");
            cbBaudRale.Items.Add("1200");
            cbBaudRale.Items.Add("2400");
            cbBaudRale.Items.Add("4800");
            cbBaudRale.Items.Add("9600");
            cbBaudRale.Items.Add("19200");
            cbBaudRale.Items.Add("38400");
            cbBaudRale.Items.Add("43000");
            cbBaudRale.Items.Add("56000");
            cbBaudRale.Items.Add("57600");
            cbBaudRale.Items.Add("115200");
            cbBaudRale.SelectedIndex = 7;//默认选中19200
        }


    }
}
