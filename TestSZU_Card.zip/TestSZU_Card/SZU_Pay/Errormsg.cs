﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestSZU_Card.SZU_Pay
{




    /// <summary>
    /// 返回值列表Errormsg.h转的枚举
    /// </summary>
    class Errormsg
    {
        /// <summary>
        /// 根据返回的（Errormsg.h）值匹配说明
        /// </summary>
        /// <param name="key">第三方操作的返回值</param>
        /// <returns>对返回值的说明</returns>
        public static string GetEnumFroByKey(int key)
        {
            string name=Enum.GetName(typeof(Errormsg_enum), key);
            if (string.IsNullOrEmpty(name))
            {
                return "【["+key+"]没有匹配到任何返回值说明!】";
            }
            return name;
        }



        /// <summary>
        /// 返回值列表Errormsg.h转的枚举
        /// </summary>
        private enum Errormsg_enum
        {
            //附：返回值定义
            截获异常ERR_EXCEPTION = -9999,

            交易成功ERR_OK = 0,

            版本不符ERR_VER = -1,

            返回码不对ERR_RETCODE = -2,

            数据长度不对ERR_LENGTH = -3,

            文件名非法ERR_FILENAME = -4,

            文件访问状态非法ERR_FILESTAT = -5,

            操作失败ERR_FAIL = -6,

            /*sios error : ERR_SIOS_ */

            指定的记录不存在ERR_SIOS_NOREC = -100,  

            下载文件失败ERR_SIOS_DOWNLOAD = -101,  



            /*net error : ERR_NET_ */

            网络连接不通ERR_NET_CONNECT = -200,  

            数据发送出错ERR_NET_SEND = -201,  

            数据接收出错ERR_NET_RECV = -202,  

            接收文件出错ERR_NET_RECVFILE = -203,  

            发送文件出错ERR_NET_SENDFILE = -204,  



            /*trans errot : ERR_TRN_ */

            无效的子系统代码ERR_TRN_SUBCODE = -300,  

            无效的站点号ERR_TRN_STATION = -301,  

            无效的签到密码ERR_TRN_SIGNPWD = -302,  





            /*EN_CARD error : ERR_ENCARD_ */

            读加密卡头错ERR_ENCARD_RHEAD = -500,  

            读配置区出错ERR_ENCARD_CONFIG = -501,  

            读密钥错ERR_ENCARD_RKEY = -502,  

            打开加密卡失败ERR_ENCARD_OPEN = -503,  

            psam卡初始化失败ERR_PSAM_INIT = -504,  

            读厂家信息失败ERR_PSAM_FACTORY = -505,  

            读本地配置信息失败ERR_PSAM_LOCAL = -506,  

            读服务器配置信息失败ERR_PSAM_SERVER = -507,  

            读密钥配置信息失败ERR_PSAM_KEY = -508,  

            读厂家授权信息失败ERR_PSAM_AUTH = -509,  

            读子系统授权信息失败ERR_PSAM_SAUTH = -510,  





            /*DLL error : ERR_DLL_ from=-1000 */

            SIOS没有正常运行ERR_DLL_SIOS = -1001,  

            DSQL操作错误ERR_DLL_DSQL = -1002,  

            分配的缓冲区太小_不能拷贝ERR_DLL_BUF_MIN = -1003,  

            解包出错ERR_DLL_UNPACK = -1004,  

            重做业务2003_09_05_ERR_DLL_REDO = -1005,  

            没有相片文件ERR_DLL_NOPHOTO = -1006,  

            指定文件不存在ERR_DLL_NOFILE = -1007,  



            /*定义升级返回值 from 1100*/

            文件已经存在ERR_FILEEXIST = -1100,  

            操作被拒绝ERR_REFUSE = -1101,  

            没有文件ERR_NO_FILE = -1102,  

            删除文件失败ERR_DEL_FAIL = -1103,  

            通讯失败ERR_COMM_FAIL = -1104,  





            /*第三方返回值定义 from 1200*/

            交易额错误ERR_TA_TRANAMT = -1200,  

            第三方API没有初始化ERR_TA_NOT_INIT = -1201,  

            读卡器错误ERR_TA_CARDREADER = -1202,  

            读卡失败ERR_TA_READCARD = -1203,  

            写卡失败ERR_TA_WRITECARD = -1204,  

            函数调用功能限制ERR_TA_LIMIT_FUNC = -1205,  

            不是消费卡ERR_TA_CARDTYPE = -1206,  

            非本院校卡ERR_TA_SNO = -1207,  

            过期卡ERR_TA_EXPIRECARD = -1208,  

            修改用卡次数失败ERR_TA_FAIL_CHGUT = -1209,  

            写卡时卡号不符ERR_TA_NOT_SAMECARD = -1210,  

            卡消费时输入密码错误ERR_TA_WRONG_PWD = -1211,  

            卡内余额不足ERR_TA_LOW_BALAN = -1212,  

            超过消费限额ERR_TA_EXCEED_QUOTA=-1213  ,  

            挂失卡ERR_TA_LOST_CARD = -1214,  

            冻结卡ERR_TA_FREEZE_CARD = -1215,  

            卡号帐号不符ERR_TA_CARDNO = -1216,  

            身份关闭ERR_TA_ID_CLOSE = -1217,  

            加载读卡器动态链接库失败ERR_TA_CR_DLL = -1218,  

            读卡器初始化失败ERR_TA_CR_INIT = -1219,  

            参数错误ERR_TA_PARA = -1220,  

            没有这个帐户ERR_TA_NOREC = -1221,  

            补助成功_也是正确的返回信息ERR_TA_SUB_SUCC = -1222,  

            补助失败, 也是正确的返回信息ERR_TA_SUB_FAIL = -1223,  

            读卡器已经初始化_请关闭ERR_TA_INITED = -1224,  

            加载UpdateAPI_dll动态库失败ERR_TA_UP_DLL = -1225,  

            回写卡余额失败ERR_TA_WRITECARD2 = -1226,  

            查询帐户失败ERR_TA_QUERYACC = -1227,  

            写卡时候重新读卡余额失败ERR_TA_REREADCARD = -1228,  

            没有找到函数入口ERR_TA_NO_FUN = -1229,  

            读到的卡片用卡次数为65536_需要重新读取ERR_TA_READ_65536 = -1230,  

            读到的卡片用卡次数为0_需要重新读取ERR_TA_READ_0 = -1231,  
        }
    }
}
