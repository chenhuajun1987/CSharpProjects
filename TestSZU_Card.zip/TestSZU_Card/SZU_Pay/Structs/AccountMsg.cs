﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TestSZU_Card.SZU_Pay.Structs
{
    /// <summary>
    /// AccountMsg 账户结构体
    /// </summary>
    //[StructLayout(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐(系统默认的pack是4)
    [StructLayoutAttribute(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐
    //[StructLayoutAttribute(LayoutKind.Explicit, Pack = 1)]//设置内存对齐方式，1字节对齐
    public struct AccountMsg
    {
        /// <summary>
        /// 姓名
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        //[FieldOffset(0)]
        //[FieldOffsetAttribute(0)]
        public string Name;           /*姓名*/

        /// <summary>
        /// 性别代码
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 2)]
        public string SexNo;           /*性别*/

        /// <summary>
        /// 部门代码
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 19)]
        public string DeptCode;       /*部门代码*/

        /// <summary>
        /// 卡号
        /// </summary>
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        //public byte[] CardNo;             /*卡号*/
        [MarshalAs(UnmanagedType.U4)]
        public uint CardNo;             /*卡号*/

        /// <summary>
        /// 帐号
        /// </summary>
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        //public byte[] AccountNo;          /*帐号*/
        [MarshalAs(UnmanagedType.U4)]
        public uint AccountNo;          /*帐号*/

        /// <summary>
        /// 学号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        public string StudentCode;    /*学号*/

        /// <summary>
        /// 身份证号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        public string IDCard;         /*身份证号*/

        /// <summary>
        /// 身份代码
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 3)]
        public string PID;             /*身份代码*/

        /// <summary>
        /// 身份序号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 13)]
        public string IDNo;           /*身份序号*/

        /// <summary>
        /// 现余额
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public int Balance;            /*现余额*/

        /// <summary>
        /// 消费密码
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 7)]
        public string Password;        /*消费密码*/

        /// <summary>
        /// 账户截止日期
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 7)]
        public string ExpireDate;      /*账户截止日期*/

        /// <summary>
        /// 补助戳
        /// </summary>
        [MarshalAs(UnmanagedType.U2)]
        public ushort SubSeq;             /*补助戳*/

        /// <summary>
        /// 是否在本系统内开通
        /// </summary>
        [MarshalAs(UnmanagedType.I1)]
        public bool IsOpenInSys;        /*是否在本系统内开通*/

        /// <summary>
        /// 终端号码,提取补助时需要填写
        /// </summary>
        [MarshalAs(UnmanagedType.I2)]
        public short TerminalNo;         /*终端号码,提取补助时需要填写*/

        /// <summary>
        /// 后台处理返回值
        /// </summary>
        [MarshalAs(UnmanagedType.I2)]
        public short RetCode;            /*后台处理返回值*/

        /// <summary>
        /// 状态(2004-08-26增加
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
        public string Flag;           /*状态(2004-08-26增加)*/

        /// <summary>
        /// 卡类型
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        public string CardType;        /*卡类型*/

        /// <summary>
        /// 电子账户类型，如果输入则会查询相应的电子帐户余额
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        public string AccType;         /*电子账户类型，如果输入则会查询相应的电子帐户余额*/

        /// <summary>
        /// 卡片上的用卡次数
        /// </summary>
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        //public byte[] UsedCardNum;        /*卡片上的用卡次数*/
        [MarshalAs(UnmanagedType.U2)]
        public ushort UsedCardNum;        /*卡片上的用卡次数*/

        /// <summary>
        /// 精确查询时根据输入的AccType查询到的电子帐户余额
        /// </summary>
        //[MarshalAs(UnmanagedType.I8)]
        //public long AccAmt;             /*精确查询时根据输入的AccType查询到的电子帐户余额*/
        [MarshalAs(UnmanagedType.I4)]
        public int AccAmt;             /*精确查询时根据输入的AccType查询到的电子帐户余额*/

        /// <summary>
        /// 读卡的时候作为输入参数表示是否使用PSAM做内部认证，1使用，0不使用
        /// </summary>
        [MarshalAs(UnmanagedType.I1)]
        public bool bUseInternalAuth;       /*读卡的时候作为输入参数表示是否使用PSAM做内部认证，1使用，0不使用*/

        /// <summary>
        /// 预留字段
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 69)]
        public string Pad;                /*预留字段*/
    }




    /// <summary>
    /// AccountMsg 账户结构体 （Explicit版，自定义对齐内存）
    /// </summary>
    //[StructLayout(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐(系统默认的pack是4)
    //[StructLayoutAttribute(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐
    [StructLayoutAttribute(LayoutKind.Explicit, Pack = 1)]//设置内存对齐方式，1字节对齐
    public struct AccountMsg_Explicit
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        //[FieldOffset(0)]
        [FieldOffsetAttribute(0)]//内存起始位
        public string Name;           /*姓名*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 2)]
        [FieldOffset(21)]
        public string SexNo;           /*性别*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 19)]
        [FieldOffset(23)]
        public string DeptCode;       /*部门代码*/

        [MarshalAs(UnmanagedType.U4)]
        [FieldOffset(42)]
        public uint CardNo;             /*卡号*/

        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        //public byte[] AccountNo;          /*帐号*/
        [MarshalAs(UnmanagedType.U4)]
        [FieldOffset(46)]
        public uint AccountNo;          /*帐号*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        [FieldOffset(50)]
        public string StudentCode;    /*学号*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        [FieldOffset(71)]
        public string IDCard;         /*身份证号*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 3)]
        [FieldOffset(92)]
        public string PID;             /*身份代码*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 13)]
        [FieldOffset(95)]
        public string IDNo;           /*身份序号*/

        [MarshalAs(UnmanagedType.I4)]
        [FieldOffset(108)]
        public int Balance;            /*现余额*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 7)]
        [FieldOffset(112)]
        public string Password;        /*消费密码*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 7)]
        [FieldOffset(119)]
        public string ExpireDate;      /*账户截止日期*/

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        [FieldOffset(126)]
        public byte[] SubSeq;             /*补助戳*/

        [MarshalAs(UnmanagedType.I1)]
        [FieldOffset(128)]
        public bool IsOpenInSys;        /*是否在本系统内开通*/

        [MarshalAs(UnmanagedType.I2)]
        [FieldOffset(129)]
        public short TerminalNo;         /*终端号码,提取补助时需要填写*/

        [MarshalAs(UnmanagedType.I2)]
        [FieldOffset(131)]
        public short RetCode;            /*后台处理返回值*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
        [FieldOffset(133)]
        public string Flag;           /*状态(2004-08-26增加)*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        [FieldOffset(149)]
        public string CardType;        /*卡类型*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        [FieldOffset(153)]
        public string AccType;         /*电子账户类型，如果输入则会查询相应的电子帐户余额*/

        [MarshalAs(UnmanagedType.U2)]
        [FieldOffset(157)]
        public ushort UsedCardNum;        /*卡片上的用卡次数*/

        [MarshalAs(UnmanagedType.I4)]
        [FieldOffset(159)]
        public int AccAmt;             /*精确查询时根据输入的AccType查询到的电子帐户余额*/

        [MarshalAs(UnmanagedType.I1)]
        [FieldOffset(163)]
        public bool bUseInternalAuth;       /*读卡的时候作为输入参数表示是否使用PSAM做内部认证，1使用，0不使用*/

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 69)]
        [FieldOffset(164)]
        public string Pad;                /*预留字段*/
    }//总共233字节



    /// <summary>
    /// AccountMsg 账户结构体,调试用
    /// </summary>
    public struct AccountMsg_Debug
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 255)]//233
        public byte[] debugByteArry;
    }
}
