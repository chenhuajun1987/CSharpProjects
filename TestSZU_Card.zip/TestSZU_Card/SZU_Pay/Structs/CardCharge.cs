﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TestSZU_Card.SZU_Pay.Structs
{
    /// <summary>
    /// 第三方卡片收费CardCharge数据包
    /// </summary>
    [StructLayoutAttribute(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐(默认4字节)
    public struct CardCharge
    {
        /// <summary>
        /// 操作员
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        public string Operator;

        /// <summary>
        /// 帐号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        public uint AccountNo;

        /// <summary>
        /// 商户帐号2004-04-28增加
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        public uint MercAcc;

        /// <summary>
        /// 卡号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        public uint CardNo;

        /// <summary>
        /// 收费ID号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        uint FeeID;

        /// <summary>
        /// 交易额,精确至分
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        int TranAmt;

        /// <summary>
        /// 收费类型
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        string ConsumeType;

        /// <summary>
        /// FeeFlag[0]：0_自助交费 1_自动交费
        /// FeeFlag[1]：0_校园卡交费 1_银行卡交费 2_现金交费 3_银行代收
        /// FeeFlag[2]：0_已交费 1_未交费 2_已对帐 3_已核销 4_已作废
        /// FeeFlag[3]: 0_一次交清	1_分期交费
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 6)]
        string FeeFlag;            /*FeeFlag[0]：0_自助交费 1_自动交费*/
                                   /*FeeFlag[1]：0_校园卡交费 1_银行卡交费 2_现金交费 3_银行代收 */
                                   /*FeeFlag[2]：0_已交费 1_未交费 2_已对帐 3_已核销 4_已作废*/
                                   /*FeeFlag[3]:  0_一次交清	1_分期交费*/

        /// <summary>
        /// 费用描述
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 31)]
        string FeeDesc;

        /// <summary>
        /// 卡余额,精确至分
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        int CardBalance;

        /// <summary>
        /// 终端编号
        /// </summary>
        [MarshalAs(UnmanagedType.U2)]
        ushort TerminalNo;

        /// <summary>
        /// 费用时序
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 11)]
        string FeeTerm;

        /// <summary>
        /// 银行卡号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        string BankAcc;

        /// <summary>
        /// 中文名姓名
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 31)]
        string Cname;

        /// <summary>
        /// 身份证号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        string IdentityCode;

        /// <summary>
        /// 滞纳金额 精确至分
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        int LateFeeAmt;

        /// <summary>
        /// 滞纳金率
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        int LateFeeRate;

        /// <summary>
        /// 滞纳金起计日期 YYYYMMDD
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 15)]
        string LateFeeStDate;

        /// <summary>
        /// 必交费有效期
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 15)]
        string ExpDate;

        /// <summary>
        /// 票据编号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 51)]
        string BillNo;

        /// <summary>
        /// 交易流水号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        uint TranJnl;

        /// <summary>
        /// 后台交易流水号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        uint BackJnl;           /**/

        /// <summary>
        /// 后台处理返回值
        /// </summary>
        [MarshalAs(UnmanagedType.I2)]
        short RetCode;

    }
}
