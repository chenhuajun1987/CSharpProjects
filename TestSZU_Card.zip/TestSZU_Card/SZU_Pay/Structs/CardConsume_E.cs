﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TestSZU_Card.SZU_Pay.Structs
{
    /// <summary>
    /// 第三方电子帐户收费CardConsume_E数据包(E账户)  电子账户转账的包
    /// </summary>
    [StructLayoutAttribute(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐(默认4字节)
    public struct CardConsume_E
    {
        /// <summary>
        /// 帐号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        public uint AccountNo;                /**/

        /// <summary>
        /// 卡号（10位物理卡号）
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        public uint CardNo;                            /*卡号*/

        /// <summary>
        /// 财务类型
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 3)]
        public string FinancingType; /*财务类型*/

        /// <summary>
        /// 卡余额,精确至分
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public int CardBalance;              /*卡余额,精确至分*/

        /// <summary>
        /// 交易额,精确至分
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        public int TranAmt;                     /*交易额,精确至分*/

        /// <summary>
        /// 用卡次数，交易前
        /// </summary>
        [MarshalAs(UnmanagedType.U2)]
        public ushort UseCardNum;                    /*用卡次数，交易前*/

        /// <summary>
        /// 终端编号
        /// </summary>
        [MarshalAs(UnmanagedType.U2)]
        public ushort TerminalNo;                /*终端编号*/

        /// <summary>
        /// 卡密码
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 7)]
        public string PassWord;              /*卡密码*/

        /// <summary>
        /// 操作员
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 3)]
        public string Operator;         /*操作员*/

        /// <summary>
        /// 摘要
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 129)]
        public string Abstract;             /*摘要*/

        /// <summary>
        /// 交易流水号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        public uint TranJnl;                /*交易流水号*/

        /// <summary>
        /// 后台交易流水号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        public uint BackJnl;               /*后台交易流水号*/

        /// <summary>
        /// 后台处理返回值
        /// </summary>
        [MarshalAs(UnmanagedType.I2)]
        public short RetCode;                    /*后台处理返回值*/

        /// <summary>
        /// 转出帐户类型
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        public string AccType;                /*转出帐户类型*/

        /// <summary>
        /// 转入帐户类型
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        public string SubType;                /*转入帐户类型*/

        /// <summary>
        /// 扩展字段(为电子帐户05-08-17新增)
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 100)]
        public string Reserved;           /*扩展字段(为电子帐户05-08-17新增)*/
    }
}
