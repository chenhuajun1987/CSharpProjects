﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TestSZU_Card.SZU_Pay.Structs
{
    /// <summary>
    /// 查询交易流水的数据包
    /// </summary>
    [StructLayoutAttribute(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐(默认4字节)
    public struct InqTranFlow_E
    {
        /// <summary>
        /// 查询类型,0-查询当日流水;1-历史流水
        /// </summary>
        [MarshalAs(UnmanagedType.U1)]
        char InqType;

        /// <summary>
        /// 持卡人帐号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        uint Account;           /**/

        /// <summary>
        /// 商户帐号
        /// </summary>
        [MarshalAs(UnmanagedType.U4)]
        uint MercAcc;           /**/

        /// <summary>
        /// 终端号码
        /// </summary>
        [MarshalAs(UnmanagedType.I2)]
        short TerminalNo;           /**/

        /// <summary>
        /// 起始时间,YYYYMMDDHHMMSS
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 15)]
        string StartTime;     /**/

        /// <summary>
        /// 结束时间,YYYYMMDDHHMMSS
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 15)]
        string EndTime;       /**/

        /// <summary>
        /// 接收到的文件名称
        /// </summary>
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
        string FileName;      /**/

        /// <summary>
        /// 查询到的记录数目
        /// </summary>
        [MarshalAs(UnmanagedType.I4)]
        int RecNum;				/**/
    }
}
