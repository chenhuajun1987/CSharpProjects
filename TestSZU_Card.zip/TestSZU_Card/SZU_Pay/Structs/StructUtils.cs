﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestSZU_Card.SZU_Pay.Structs
{
    class StructUtils
    {
        /// <summary>
        /// 将AccountMsg转为字符串
        /// </summary>
        /// <param name="accountMsg"></param>
        /// <returns></returns>
        public static string AccountMsgToString(AccountMsg accountMsg)
        {
            return ""
            //+ "姓名Name:-" + accountMsg.Name + "-\r\n"
            + "姓名Name:-" + accountMsg.Name + "-\r\n"

            + "性别SexNo:-" + accountMsg.SexNo + "-\r\n"

            + "部门代码DeptCode:-" + accountMsg.DeptCode + "-\r\n"

            //+ "卡号CardNo:-" + BitConverter.ToUInt32(accountMsg.CardNo.ToArray(), 0) + "-\r\n"
            + "卡号CardNo:-" + accountMsg.CardNo + "-\r\n"

            //+ "帐号AccountNo:-" + BitConverter.ToUInt32(accountMsg.AccountNo.ToArray(), 0) + "-\r\n"
            + "帐号AccountNo:-" + accountMsg.AccountNo + "-\r\n"

            + "学号StudentCode:-" + accountMsg.StudentCode + "-\r\n"

            + "身份证号IDCard:-" + accountMsg.IDCard + "-\r\n"

            + "身份代码PID:-" + accountMsg.PID + "-\r\n"

            + "身份序号IDNo:-" + accountMsg.IDNo + "-\r\n"

            + "现余额Balance:-" + accountMsg.Balance + "-\r\n"

            + "消费密码Password:-" + accountMsg.Password + "-\r\n"

            + "账户截止日期ExpireDate:-" + accountMsg.ExpireDate + "-\r\n"

            + "补助戳SubSeq:-" + accountMsg.SubSeq + "-\r\n"

            + "是否在本系统内开通IsOpenInSys:-" + accountMsg.IsOpenInSys + "-\r\n"

            + "终端号码,提取补助时需要填写TerminalNo:-" + accountMsg.TerminalNo + "-\r\n"

            + "后台处理返回值RetCode:-" + accountMsg.RetCode + "-\r\n"

            + "状态(2004-08-26增加)Flag:-" + accountMsg.Flag + "-\r\n"

            + "卡类型CardType:-" + accountMsg.CardType + "-\r\n"

            + "电子账户类型，如果输入则会查询相应的电子帐户余额AccType:-" + accountMsg.AccType + "-\r\n"

            //+ "卡片上的用卡次数UsedCardNum:-" + BitConverter.ToUInt16(accountMsg.UsedCardNum.ToArray(), 0) + "-"+accountMsg.UsedCardNum[0]+accountMsg.UsedCardNum[1]+"\r\n"
            + "卡片上的用卡次数UsedCardNum:-" + accountMsg.UsedCardNum + "-\r\n"

            + "精确查询时根据输入的AccType查询到的电子帐户余额AccAmt:-" + accountMsg.AccAmt + "-\r\n"

            + "读卡的时候作为输入参数表示是否使用PSAM做内部认证，1使用，0不使用bUseInternalAuth:-" + accountMsg.bUseInternalAuth + "-\r\n"

            + "预留字段Pad:-" + accountMsg.Pad + "-\r\n";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cardConsume_E"></param>
        /// <returns></returns>
        public static string CardConsume_E_ToString(CardConsume_E cardConsume_E)
        {
            return ""
                +"账号AccountNo:-" + cardConsume_E.AccountNo + "-\r\n"

                + "卡号CardNo:-" + cardConsume_E.CardNo + "-\r\n"

                + "财务类型FinancingType:-" + cardConsume_E.FinancingType + "-\r\n"

                + "卡余额,精确至分CardBalance:-" + cardConsume_E.CardBalance + "-\r\n"

                + "交易额,精确至分TranAmt:-" + cardConsume_E.TranAmt + "-\r\n"

                + "用卡次数，交易前UseCardNum:-" + cardConsume_E.UseCardNum + "-\r\n"

                + "终端编号TerminalNo:-" + cardConsume_E.TerminalNo + "-\r\n"

                + "卡密码PassWord:-" + cardConsume_E.PassWord + "-\r\n"

                + "操作员Operator:-" + cardConsume_E.Operator + "-\r\n"

                + "摘要Abstract:-" + cardConsume_E.Abstract + "-\r\n"

                + "交易流水号TranJnl:-" + cardConsume_E.TranJnl + "-\r\n"

                + "后台交易流水号BackJnl:-" + cardConsume_E.BackJnl + "-\r\n"

                + "后台处理返回值RetCode:-" + cardConsume_E.RetCode + "-\r\n"

                + "转出帐户类型AccType:-" + cardConsume_E.AccType + "-\r\n"

                + "转入帐户类型SubType:-" + cardConsume_E.SubType + "-\r\n"

                + "扩展字段(为电子帐户05-08-17新增)Reserved:-" + cardConsume_E.Reserved + "-\r\n"

                ;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cardConsume"></param>
        /// <returns></returns>
        public static string CardConsumeToString(CardConsume cardConsume)
        {
            return ""
                +"账号AccountNo:-" + cardConsume.AccountNo + "-\r\n"

                + "卡号CardNo:-" + cardConsume.CardNo + "-\r\n"

                + "财务类型FinancingType:-" + cardConsume.FinancingType + "-\r\n"

                + "卡余额,精确至分CardBalance:-" + cardConsume.CardBalance + "-\r\n"

                + "交易额,精确至分TranAmt:-" + cardConsume.TranAmt + "-\r\n"

                + "用卡次数，交易前UseCardNum:-" + cardConsume.UseCardNum + "-\r\n"

                + "终端编号TerminalNo:-" + cardConsume.TerminalNo + "-\r\n"

                + "卡密码PassWord:-" + cardConsume.PassWord + "-\r\n"

                + "操作员Operator:-" + cardConsume.Operator + "-\r\n"

                + "摘要Abstract:-" + cardConsume.Abstract + "-\r\n"

                + "交易流水号TranJnl:-" + cardConsume.TranJnl + "-\r\n"

                + "后台交易流水号BackJnl:-" + cardConsume.BackJnl + "-\r\n"

                + "后台处理返回值RetCode:-" + cardConsume.RetCode + "-\r\n"

                //+ "转出帐户类型AccType:-" + cardConsume.AccType + "-\r\n"

                //+ "转入帐户类型SubType:-" + cardConsume.SubType + "-\r\n"

                //+ "扩展字段(为电子帐户05-08-17新增)Reserved:-" + cardConsume.Reserved + "-\r\n"

                ;
        }
    }
}
