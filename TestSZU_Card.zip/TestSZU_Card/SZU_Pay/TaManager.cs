﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using TestSZU_Card.SZU_Pay.Structs;

namespace TestSZU_Card.SZU_Pay
{
    /// <summary>
    /// 账户信息结构体
    /// </summary>
    //    //[StructLayout(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐(系统默认的pack是4)
    //    [StructLayoutAttribute(LayoutKind.Sequential, Pack = 1)]//设置内存对齐方式：按顺序对齐，1字节对齐
    //    //[StructLayoutAttribute(LayoutKind.Explicit, Pack = 1)]//设置内存对齐方式，1字节对齐
    //    public struct AccountMsg
    //    {
    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
    //        //[FieldOffset(0)]
    //        //[FieldOffsetAttribute(0)]
    //        public string Name;           /*姓名*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 2)]
    //        public string SexNo;           /*性别*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 19)]
    //        public string DeptCode;       /*部门代码*/

    //        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    //        //public byte[] CardNo;             /*卡号*/
    //        [MarshalAs(UnmanagedType.U4)]
    //        public uint CardNo;             /*卡号*/

    //        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
    //        //public byte[] AccountNo;          /*帐号*/
    //        [MarshalAs(UnmanagedType.U4)]
    //        public uint AccountNo;          /*帐号*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
    //        public string StudentCode;    /*学号*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
    //        public string IDCard;         /*身份证号*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 3)]
    //        public string PID;             /*身份代码*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 13)]
    //        public string IDNo;           /*身份序号*/

    //        [MarshalAs(UnmanagedType.I4)]
    //        public int Balance;            /*现余额*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 7)]
    //        public string Password;        /*消费密码*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 7)]
    //        public string ExpireDate;      /*账户截止日期*/

    //        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    //        public byte[] SubSeq;             /*补助戳*/

    //        [MarshalAs(UnmanagedType.I1)]
    //        public bool IsOpenInSys;        /*是否在本系统内开通*/

    //        [MarshalAs(UnmanagedType.I2)]
    //        public short TerminalNo;         /*终端号码,提取补助时需要填写*/

    //        [MarshalAs(UnmanagedType.I2)]
    //        public short RetCode;            /*后台处理返回值*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
    //        public string Flag;           /*状态(2004-08-26增加)*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
    //        public string CardType;        /*卡类型*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
    //        public string AccType;         /*电子账户类型，如果输入则会查询相应的电子帐户余额*/

    //        [MarshalAs(UnmanagedType.U2)]
    //        public ushort UsedCardNum;        /*卡片上的用卡次数*/
    //        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    //        //public byte[] UsedCardNum;        /*卡片上的用卡次数*/

    //        //[MarshalAs(UnmanagedType.I8)]
    //        //public long AccAmt;             /*精确查询时根据输入的AccType查询到的电子帐户余额*/
    //        [MarshalAs(UnmanagedType.I4)]
    //        public int AccAmt;             /*精确查询时根据输入的AccType查询到的电子帐户余额*/

    //        [MarshalAs(UnmanagedType.I1)]
    //        public bool bUseInternalAuth;       /*读卡的时候作为输入参数表示是否使用PSAM做内部认证，1使用，0不使用*/

    //        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 69)]
    //        public string Pad;                /*预留字段*/
    //    }


    /// <summary>
    /// SZU第三方接入一卡通动态库函数方法
    /// </summary>
    class TaManager
    {
        /// <summary>
        /// 动态库
        /// </summary>
        private const string AIO_API = "AIO_API.dll";//动态库


        /// <summary>
        /// 初始化第三方动态库
        /// </summary>
        /// <param name="IP">第三方代理服务器SIOS的IP地址</param>
        /// <param name="port">第三方代理服务器sios 的端口号</param>
        /// <param name="SysCode">给第三方系统分配的系统代码</param>
        /// <param name="TerminalNo">终端编号</param>
        /// <param name="ProxyOffline">ProxyOffline-代理服务是否脱机</param>
        /// <param name="MaxJnl">最大流水号</param>
        /// <returns>TRUE/FALSE</returns>
        [DllImport(AIO_API, EntryPoint = "TA_Init", CallingConvention = CallingConvention.Winapi)]
        //public static extern bool TA_Init(string IP, short port, ushort SysCode, ushort TerminalNo, out bool ProxyOffline, out ulong MaxJnl);
        public static extern bool TA_Init(string IP, short port, ushort SysCode, ushort TerminalNo, out bool ProxyOffline, out uint MaxJnl);


        /// <summary>
        /// 获取持卡人账户信息  ,根据帐号/卡号/学工号/证件号精确查询帐户信息
        /// </summary>
        /// <param name="pAccMsg">
        ///          pAccMsg->AccountNo – 消费卡片的帐号
        ///          pAccMsg->CardNo – 消费卡的卡号
        ///          pAccMsg-> StudentCode – 学工号
        ///          pAccMsg->IDCard - 证件号码
        /// </param>
        /// <param name="TimeOut">交易超时时间，缺省为10秒</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_InqAcc", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_InqAcc(ref AccountMsg pAccMsg, short TimeOut=10);
        //下面调试用
        [DllImport(AIO_API, EntryPoint = "TA_InqAcc", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_InqAcc_Debug(ref AccountMsg_Debug pAccMsg, short TimeOut=10);


        /// <summary>
        /// 根据帐号/卡号/学工号/证件号精确查询帐户信息及其扩展信息
        /// </summary>
        /// <param name="pAccMsg">pAccMsg－第三方帐户信息的整体数据包
        ///(需要填写卡号或者是帐号或者是学工号或者是证件号)。
 		///	pAccMsg->RetCode- 输出参数 , 为后台处理的返回值
        ///	</param>
        /// <param name="TimeOut">TimeOut － 输入参数，超时时间（秒），缺省值为10秒。</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_InqAccEx", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_InqAccEx(ref AccountMsg pAccMsg, short TimeOut=10);
        //下面调试用
        [DllImport(AIO_API, EntryPoint = "TA_InqAccEx", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_InqAccEx_Debug(ref AccountMsg_Debug pAccMsg, short TimeOut=10);


        /// <summary>
        /// 第三方根据帐号和卡号检查白名单
        /// </summary>
        /// <param name="AccountNo">AccountNo-需要验证的帐号</param>
        /// <param name="CardNo">CardNo-需要验证的卡号</param>
        /// <param name="CheckID">CheckID-是否验证身份的开通关闭状态</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_CheckWL", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_CheckWL(uint AccountNo, uint CardNo, bool CheckID = true);



        /// <summary>
        /// 第三方电子账户消费,E账户消费
        /// </summary>
        /// <param name="pCardCons">第三方电子帐户收费CardConsume_E数据包,pCardCons->RetCode是后台交易的返回值</param>
        /// <param name="TimeOut">TimeOut － 输入参数，超时时间（秒），缺省值为10秒。</param>
        /// <returns>见返回值列表Errormsg.h</returns>
        [DllImport(AIO_API, EntryPoint = "TA_Elec_Consume", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_Elec_Consume(ref CardConsume_E pCardCons, short TimeOut = 10);

        /// <summary>
        /// E账户交易流水查询
        /// </summary>
        /// <param name="pInqTranFlow_E">pInqTranFlow－输入参数,可以根据持卡人帐号、商户帐号、终端号码组合查询当天的或者历史的交易流水。
        /// 查询的文件放到RecvTemp目录下，文件名写入到pInqTranFlow->FileName中。	pInqTranFlow->RecNum-输出参数，查询到的记录数目
        /// </param>
        /// <param name="TimeOut">TimeOut － 输入参数，超时时间（秒），缺省值为10秒。</param>
        /// <returns>见返回值列表Errormsg.h</returns>
        [DllImport(AIO_API, EntryPoint = "TA_InqTranFlow", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_InqTranFlow(ref InqTranFlow_E pInqTranFlow_E, short TimeOut = 10);









        /// <summary>
        /// 第三方DSQL查询(返回二进制文件或者文本文件)
        /// </summary>
        /// <param name="Dsql">Dsql ：sql语句 </param>
        /// <param name="fillGap">fillGap:分割符(如果是'\0'返回二进制文件，其他返回以FillGap分隔的文本文件)；</param>
        /// <param name="fn">fn：返回的文件名</param>
        /// <param name="nBlockNum">nblocknum：返回的记录数目；</param>
        /// <param name="RetCode">RetCode：Dsql查询的返回值</param>
        /// <param name="timeOut">timeOut－超时时间</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_Dsql_QFile", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_Dsql_QFile(string Dsql,char fillGap,string fn,out int nBlockNum,out int RetCode,short timeOut = 10);
        //select AccountNo from PersonInformation where StudentNo = '%s'
        //select * from PersonInformation




        /// <summary>
        /// 第三方DSQL精确查询(返回一条二进制记录或者文本记录, size < 1024)
        /// </summary>
        /// <param name="Dsql">Dsql：sql语句；</param>
        /// <param name="fillGap">fillGap:分割符 (如果是'\0'返回二进制文件，其他返回以FillGap分隔的文本文件)；</param>
        /// <param name="sBlock">sBlock：返回记录缓冲区(size = 1024)</param>
        /// <param name="nBlockSize">nBlockSize：输入输出参数，输入－缓冲区的的大小，输出－返回的记录大小</param>
        /// <param name="RetCode">RetCode：Dsql查询的返回值</param>
        /// <param name="timeOut">timeOut－超时时间</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_Dsql_QRecord", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_Dsql_QRecord(string Dsql,char fillGap,out string sBlock, out int nBlockSize,out int RetCode,short timeOut = 10);







        /// <summary>
        /// 初始化读卡器
        /// </summary>
        /// <param name="CardReaderType">读卡器类型，0为usb类型读卡器，1为串口读卡器</param>
        /// <param name="port">串口读卡器的串口号，0～1分别代表串口1～4</param>
        /// <param name="Baud_Rate">串口读卡器的波特率</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_CRInit", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_CRInit(byte CardReaderType, int port, int Baud_Rate);//TA_CRInit相关参数是：CardReaderType:0, port:1, Baud_Rate:19200


        /// <summary>
        /// 快速读卡
        /// </summary>
        /// <param name="CardNo">卡片读出的卡号</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_FastGetCardNo", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_FastGetCardNo(out uint CardNo);


        /// <summary>
        /// 简单读卡信息，不检验白名单。
        /// </summary>
        /// <param name="pAccMsg">pAccMsg－输出参数，从卡片中读出的卡片信息</param>
        /// <returns>见返回值列表Errormsg.h</returns>
        [DllImport(AIO_API, EntryPoint = "TA_ReadCardSimple", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_ReadCardSimple(ref AccountMsg pAccMsg);
        //下面调试用
        [DllImport(AIO_API, EntryPoint = "TA_ReadCardSimple", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_ReadCardSimple_Debug(ref AccountMsg_Debug pAccMsg);


        /// <summary>
        /// 读卡信息。读出卡信息并检验白名单，判断卡片的有效性。
        /// </summary>
        /// <param name="pAccMsg">pAccMsg－帐户信息包,如果需要请求补助时必须填写pAccMsg->TerminalNo</param>
        /// <param name="CheckID">CheckID－输入参数，是否检验身份开通关闭状态</param>
        /// <param name="CheckSub">CheckSub－输入参数，是否提取补助</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_ReadCard",  CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_ReadCard(ref AccountMsg pAccMsg, bool CheckID = true, bool CheckSub = false);
        //下面调试用
        [DllImport(AIO_API, EntryPoint = "TA_ReadCard",  CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_ReadCard_Debug(ref AccountMsg_Debug pAccMsg, bool CheckID = true, bool CheckSub = false);



        /// <summary>
        /// 卡片消费(可以脱机)
        /// </summary>
        /// <param name="pCardCons">pCardCons－第三方操作的整体数据包,要求必须填入卡号 
        /// pCardCons-> CardNo – 消费卡片的卡号
        /// pCardCons ->Operator –操作员代码的操作员代码，填写两个字节的操作员代码
        /// pCardCons->TranAmt – 卡片消费的交易额，必须小于0
        /// pCardCons->TranJnl - 流水号
        /// 出口参数：    
        /// pCardCons ->RetCode – 后台交易的返回值，可以从控制文件中查询得到 
        /// pCardCons->BackJnl – 交易的后台流水号
        /// pCardCons->Balance – 卡片余额。
        /// </param>
        /// <param name="IsVerfy">IsVerfy – 是否验证消费限额，第一次调用时需要验证，
        /// 如果返回值是超过消费限额，则第三方程序验证消费密码，如果验证通过，
        /// 这个参数就可以设置为false（不验证消费限额），如果验证不通过，继续验证密码。
        /// </param>
        /// <param name="TimeOut">TimeOut － 输入参数，超时时间（秒），缺省值为10秒。</param>
        /// <returns>见返回值列表Errormsg.h</returns>
        [DllImport(AIO_API, EntryPoint = "TA_Consume", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_Consume(ref CardConsume pCardCons, bool IsVerfy, short TimeOut = 10);




        /// <summary>
        /// 卡片收费
        /// </summary>
        /// <param name="pCardCharg">pCardCharg－第三方操作的整体数据包,要求必须填入卡号 pCardCharg->RetCode是后台交易的返回值</param>
        /// <param name="IsVerfy">IsVerfy－是否验证累计消费额，如果超过累计消费额，则需要输入消费密码。</param>
        /// <param name="TimeOut">TimeOut － 输入参数，超时时间（秒），缺省值为10秒。</param>
        /// <returns>见返回值列表Errormsg.h</returns>
        [DllImport(AIO_API, EntryPoint = "TA_Charge", CallingConvention = CallingConvention.StdCall)]
        public static extern int TA_Charge(ref CardCharge pCardCharg, bool IsVerfy, short TimeOut = 10);































        /// <summary>
        /// 读卡器初始化
        /// </summary>
        /// <param name="port">Port-[in],如果为串口读卡器,表示打开的串口号,如果为usb读卡器,这两个参数保留</param>
        /// <param name="Baud_Rate">Baud_Rate-[in],如果为串口读卡器,表示打开的串口的通讯波特率,如果为usb读卡器,这两个参数保留	</param>
        /// <returns>返回打开串口和usb后的句柄,如果为INVALID_HANDLE_VALUE,表示打开失败</returns>
        [DllImport("ReadCardUSB.dll", EntryPoint = "ReadCard_Init", CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr ReadCard_Init(int port, int Baud_Rate);


        /// <summary>
        /// 读卡器蜂鸣
        /// </summary>
        /// <param name="handle">Handle-[in],串口读卡器的串口句柄,如果为usb读卡器,handle参数保留</param>
        /// <param name="mSec">mSec-[in],蜂鸣的毫秒数目</param>
        /// <returns>返回-1表示失败,0表示成功</returns>
        [DllImport("ReadCardUSB.dll", EntryPoint = "Card_Beep", CallingConvention = CallingConvention.StdCall)]
        private static extern int Card_Beep(IntPtr handle, uint mSec);







        /// <summary>
        /// 读卡器蜂鸣
        /// </summary>
        /// <param name="BeepMSecond">读卡器蜂鸣的时间，单位为毫秒</param>
        /// <returns></returns>
        [DllImport(AIO_API, EntryPoint = "TA_CRBeep", CallingConvention = CallingConvention.StdCall)]
        private static extern int TA_CRBeep(uint BeepMSecond);



    }
}
